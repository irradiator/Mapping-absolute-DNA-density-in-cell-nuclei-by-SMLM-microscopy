# CellCycleHistograms_CP2.R, Gianluca Pegoraro (NCI/NIH), July 28 2014
# Modified and adapted for CellProfiler4.2.1, Hilmar Strickfaden (IMB-Mainz), May 4 2022

####
# This R script generates population histograms from single cell data generated
# by the 'CellCycleAnalysis.cpproj' CellProfiler (Version 4.2.1,
# http://www.cellprofiler.org) project file, which segments nuclei based on the
# DAPI channel and measures the integrated nuclear fluorescence intensity in the
# DAPI channel (The Images have been background corrected by subtracting the calculated
# illumination function). The CP Project outputs a 'CellCycleAnalysis_Nuclei.txt'
# file that contains single-cell data from the image analysis.

# In the working directory the script expects a subdirectory named 'CP2_CellCycle_Output'
# containing the 'CellCycleAnalysis_Nuclei.txt' file. 

#  Results tables, .png file versions of the plots and the R workspace are saved in a
# 'R_output' directory automatically generated in the working directory.

# In particular, this R script generates histograms on a per treatment basis for the DAPI Integrated Intensity attribute, which is labeled as 'Intensity_IntegratedIntensity_DapiCorr' in the 'CellCycleAnalysis_Nuclei.txt' file.

# Based on the DAPI Integrated Intensity histogram, the user can set
# gating thresholds to calculate the percentages of cells belonging to the G1, S
# and G2/M phases of the cell cycle. The percentages are then saved in the R_ouput folder in a file
# named 'CellCycle_Percentages_table.txt'.
####


#### CLEAR WORKING SPACE AND LOAD THE REQUIRED PACKAGES
rm(list = ls())

library(data.table)
library(ggplot2)
library(stringr)

## SET HISTOGRAM GRAPHICAL AND BINNING PARAMETERS
# Set the maximum value for the DAPI Integrated Intensity histogram and binning table
DAPI.max <- 14

# Set the bin width for the DAPI Integrated Intensity histogram and binning table
DAPI.binwidth <- 0.2

# Set the width and height in inches for the DAPI Integrated Intensity histogram .png file
DAPI.width <- 6
DAPI.height <- 4.5

# Create the R_output subdirectory in the working directory
dir.create('R_output')

# Set levels for treatment column. The names of the treatments appearing in the
# vector must exactly match the ones previously set in the .dv filenames.
treat.levels <- c('untreated', 'aphidicolin', 'camptothecin', 'etoposide')


#### READ AND PROCESS CP2 ANALYSIS RESULTS FROM NUCLEI.TXT FILE
# Read the the .txt file containing the CP2 cell cycle analysis results:
nuc.dt <- fread('CellCycleAnalysis_Nuclei.txt')

hist(nuc.dt$Intensity_IntegratedIntensity_DapiCorr,100)

# Regex Split pattern to extract treatment name from the result filename. The
# Regex search is expecting the .dv file name to be in this format:
# DAPI_<TreatmentName><FieldNumber>_R3D.dv. The treatment name should include
# only letters (No special carachters or spaces) and the field name only numbers.
# If you have analyzed images saved in a different file type you need to change the file name endings accordingly.
split.pat <- 'DAPI_([A-Z,a-z]+)([0-9]+)_R3D\\.dv' # Group 2 is treatment, Group 3 is field number

# Process the data.table for subsequent analyis function, extract treatment and
# field metadata from the Metadata_FileLocation column

nuc.dt[, `:=` (treatment = factor(str_match(FileName_Dapi, split.pat)[,2],levels = treat.levels),
field = as.vector(str_match(FileName_Dapi, split.pat)[,3]))]


#### GENERATE AND SAVE DAPI INTEGRATED INTENSITY HISTOGRAMS
# Modify the default 'theme_bw()' theme in ggplot2
theme_new <- theme_set(theme_bw())
theme_new <- theme_update(
    axis.text.x=element_text(angle = -90, vjust = 0.5, hjust=1, size = 6)
)

# Loop through the different treatments, generate a histogram for each
# treatment, and save it as a .png file
for (i in treat.levels){ # Loop through the different treatment names

DAPI <- ggplot(nuc.dt[treatment == i], # Plot data for only one treatment name at the time
               aes(x = Intensity_IntegratedIntensity_DapiCorr, 
                   y = ..count../sum(..count..))) + # Plot the fraction of cells as opposed to raw counts
        geom_histogram(binwidth = DAPI.binwidth, col = 'black') + # Use the preset bin.width variable
        scale_x_continuous(breaks = seq(0, DAPI.max, by = DAPI.binwidth)) + # Set the x axis breaks to match the bins boundaries
        coord_cartesian(xlim = c(0, DAPI.max)) +
        xlab('DAPI Integrated Intensity') +
        ylab('Fraction of cells') +
        ggtitle(i) 

# Save a .png version of the histogram for publication purposes
ggsave(plot =  DAPI, 
       filename = paste('R_output/DAPI_Histogram_', i, '.png', sep = ''), 
       dpi = 600, 
       width = DAPI.width,
       height = DAPI.height) 
}

#### CALCULATE THE CELL CYCLE PERCENTAGES BASED ON THE  THE HISTOGRAMS

# Set the gates thresholds to define the different cell cycle phases based on DAPI Integrated  Intensity
G1 <- c(3.0, 4.6)
S  <- c(4.6, 7.6)
G2.M <- c(7.6, 9)

# Calculate the percentages of cells belonging to G1, S and G2 based on the
# DAPI Integrated Intensity thresholds on a per treatment basis
cell.perc <- nuc.dt[, list(g1.perc = 100*(nrow(.SD[(Intensity_IntegratedIntensity_DapiCorr > G1[1]) & (Intensity_IntegratedIntensity_DapiCorr <= G1[2]),])/.N),
                           s.perc = 100*(nrow(.SD[(Intensity_IntegratedIntensity_DapiCorr > S[1]) & (Intensity_IntegratedIntensity_DapiCorr <= S[2]),])/.N),
                           g2.perc = 100*(nrow(.SD[(Intensity_IntegratedIntensity_DapiCorr > G2.M[1]) & (Intensity_IntegratedIntensity_DapiCorr <= G2.M[2]),])/.N)),
                        by = treatment]

# Save the cell cycle percentages tables
write.table(cell.perc, file = 'R_output/CellCycle_Percentages_table.txt', quote = FALSE, sep = '\t', row.names = FALSE, col.names = TRUE)

#### CALCULATE AND OUTPUT THE BINNED VALUES FOR OPTIONAL EXCEL PLOTS AND CALCULATIONS
binned.dt <- nuc.dt[, 
                  data.frame(table(cut(Intensity_IntegratedIntensity_DapiCorr, 
                  breaks = c(seq(0, DAPI.max, by = DAPI.binwidth), 1e10), # The last bin contains anything between DAPI.max and 1e10 and it is labelled as '+'
                  labels = c(seq(DAPI.binwidth, DAPI.max, by = DAPI.binwidth), '+')))),
                  by = treatment] # The values are calculated on a per treatment basis

setnames(binned.dt, 'Var1', 'Bin') # Change the name of the bin variable

write.table(binned.dt, file = 'R_output/CellCycle_BinnedFrequencies_table.txt', quote = FALSE, sep = '\t', row.names = FALSE, col.names = TRUE) 

#### DOCUMENT THE ANALYSIS SESSION AND SAVE THE WORKSPACE
writeLines(capture.output(sessionInfo()), 'R_output/SessionInfo.txt')
save.image(file = 'R_output/Workspace.RData')

