function TS2Orte
[file,path] = uigetfile('*.csv','Select a ThunderSTORM localization  file (.csv)');
%selpath = uigetdir;


        if ischar(file)
        filename=fullfile(path,file);
        data = dlmread(filename, ',', 1, 0);
        Orte  = data(:, [6 3 4 10 10 5 5 6 2 2]);
        Orte(:, 2:3) = [Orte(:,2)-min(Orte(:,2)) Orte(:,3)-min(Orte(:,3))];
        [savefile,savepath] = uiputfile('*.mat','Save file as...');
        savefilename=fullfile(savepath,savefile);
        save(savefilename, 'Orte')
        end
end