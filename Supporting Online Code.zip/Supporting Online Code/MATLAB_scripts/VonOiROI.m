load('/Users/hilmar/Documents/MATLAB/Voronoi/LAND-voronoi/BJ1/Orte.mat')


oldOrte = Orte;
max_cum_area= 50;
max_area = 20*10^(-3);
CenterCoordinatesList = [...
                       % 15000 15500 15000 15500
                       % 11300 14300 15000 18000;... %ROI001 %Heterochromatin-Rim
                       % 15500 18500 20000 23000;...   %ROI002 top-rim
                       % 17000 20000 17000 20000;... %ROI003 nucleolous
                        16000 16200 15000 15200;...   %ROI004 inside
                       %8000 25000 5000 30000
                       %   00000 00000 20000 20000;...   %Lacuna
                       %  09000 25000 05000 27000;...
                       % 9600 9700 15000 15100;... %Center
                      %%   7350 7550 7600 7800;...%Center ROI1
                         %7200 7400 7700 7900;...
                         ];
                        

n = 1;
for n = 1:size(CenterCoordinatesList,1)
    newOrte=oldOrte(oldOrte(:,2)<CenterCoordinatesList(n,2)&oldOrte(:,2)>=CenterCoordinatesList(n,1)&oldOrte(:,3)<CenterCoordinatesList(n,4)&oldOrte(:,3)>=CenterCoordinatesList(n,3),:);
    Orte = newOrte;
    clear newOrte
    cell = ClusterAnalysis(Orte,['00' num2str(n)],2);
    [smallest_vol, biggest_vol, lowest_plot_density, highest_plot_density, V, R] = ...
        cell.voronoiCluster(0,0,'/Users/hilmar/Documents/MATLAB/Voronoi/LAND-voronoi/out/', ['./complete' '00' num2str(n)], ['inset' '00' num2str(n)], max_area, max_cum_area);
    clear cell;
end
