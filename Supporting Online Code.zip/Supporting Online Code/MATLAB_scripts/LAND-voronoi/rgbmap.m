function cmap_mat = rgbmap(m)
bckgrndDensity = 0;
DensityLimit1 = 40;
DensityLimit2 = 60;
MaxDensity = 255;

bckgrndDensity = bckgrndDensity+1;


if nargin < 1
    m = size(get(gcf,'colormap'),1); 
end



cmap_mat= zeros(255,3);
cmap_mat(DensityLimit2+1:MaxDensity,1) = linspace(0.4,1,MaxDensity-(DensityLimit2))';
cmap_mat(DensityLimit1+1:DensityLimit2, 2) = linspace(0.4,1,DensityLimit2-(DensityLimit1))';
cmap_mat(bckgrndDensity+1:DensityLimit1, 3) = linspace(0.4,1, DensityLimit1-(bckgrndDensity))';
%interpolate values
%xin=linspace(0,1,m)';
%xorg=linspace(0,1,size(cmap_mat,1));

%p(:,1)=interp1(xorg,cmap_mat(:,1),xin,'linear');
%p(:,2)=interp1(xorg,cmap_mat(:,2),xin,'linear');
%p(:,3)=interp1(xorg,cmap_mat(:,3),xin,'linear');