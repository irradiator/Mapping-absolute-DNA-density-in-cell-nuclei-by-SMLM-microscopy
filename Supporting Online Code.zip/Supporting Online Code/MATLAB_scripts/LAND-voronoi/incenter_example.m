%states = shaperead('usastatehi.shp');
%st = states(47); %creates a polgon in the shape of Washington State
%stBB = st.BoundingBox;
%st_minlat = min(stBB(:,2 )); 
%st_maxlat = max(stBB(:,2 )); 
%st_latspan = st_maxlat - st_minlat;
%st_minlong = min(stBB(:,1 )); 
%st_maxlong = max(stBB(:,1 )); 
%st_longspan = st_maxlong - st_minlong;
%stX = st.X ; 
%stY = st.Y;
%numPointsIn = 42;
%for i = 1:numPointsIn 
%flagIsIn = 0;
%while ~flagIsIn 
%x(i) = st_minlong + rand(1) * st_longspan ; 
%y(i) = st_minlat + rand(1) * st_latspan ; 
%flagIsIn = inpolygon(x(i), y(i), stX, stY ); 
%end 
%end
%mapshow(st, 'edgecolor', 'r', 'facecolor', 'none ') 
%hold on 
%scatter(x, y , '.') 
%
rng default
x = rand(10,1);
y = rand(10,1);

dt = delaunayTriangulation(x,y)
IC=incenter(dt) ;
[C,r] = incenter(dt,[1:5]')
hold on
triplot(dt)
%
[XV, YV] = voronoi(IC(:,1),IC(:,2));
plot(XV,YV,'g')